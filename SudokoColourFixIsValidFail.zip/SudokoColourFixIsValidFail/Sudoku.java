public class Sudoku {
	
	public Sudoku (){
	 	MyProblemGrid gridForm = new MyProblemGrid(); 
	 	gridForm.showForm();
	}
}
	